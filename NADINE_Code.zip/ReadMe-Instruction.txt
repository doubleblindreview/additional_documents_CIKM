Instruction Manual:

For classification problem:
1. Open the main Matlab running file (A_Main_NADINE.m) under NADINE folder.
2. Follow The instruction inside A_Main_NADINE.m file.
	This file contains some instructions :
	a. Loads the dataset by choosing/setting the index of the dataset (index j).
	For example, if we set the index j==4, it will calls the RFID dataset. 
	b. Run the dataset using NADINE algorithm.
3. The main NADINE algorithm is saved in the (NADINE.m) also under NADINE folder.
4. The index i represents how many times/rounds NADINE will execute the dataset.
5. The 'results' folder is a reserved folder to save all the files that are generated when we run NADINE algorithm.
Below is the example of generated files under the results folder: 
- 4RFIDresults.mat and 4RFIDresults.fig represent the numerical result and the figure of NADINE's performance in processing the RFID dataset in the 4th round.
Note: The working path when running the algorithm be put under NADINE folder.
6. The dataset can be downloaded at the link below:
https://drive.google.com/drive/folders/1nbbiNAa6ZHIL9orNjQCQXuqyEXZ3bCdI?usp=sharing

For regression problem:
1. Open the main Matlab running file (A_Main_Run_Nadine_regression.m) under NADINE folder.
2. Follow The instruction inside A_Main_Run_Nadine_regression.m file.
