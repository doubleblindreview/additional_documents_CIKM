% This code aims to construct neural network with several hidden layer
% one can choose to either connect every hidden layer output to
% the last output or not

function nn = netconfig(layer)
nn.size                 = layer;
nn.n                    = numel(nn.size);  %  Number of layer
nn.hl                   = nn.n - 2;        %  number of hidden layer
nn.activation_function  = 'sigm';          %  Activation functions of hidden layers: 'sigm' (sigmoid) or 'tanh_opt' (optimal tanh).
nn.learningRate         = 0.01;             %  learning rate Note: typically needs to be lower when using 'sigm' activation function and non-normalized inputs.
nn.momentum             = 0.95;             %  Momentum
nn.output               = 'softmax';       %  output unit 'sigm' (=logistic), 'softmax' and 'linear'

%% initiate weights and weight momentum for hidden layer
for i = 2 : nn.n - 1
    nn.W {i - 1} = normrnd(0,1/sqrt(nn.size(i - 1)),nn.size(i),nn.size(i - 1)+1);
%     nn.W {i - 1} = (rand(nn.size(i),nn.size(i - 1)+1) - 0.5) * 2 * 4 * sqrt(6 / (nn.size(i) + nn.size(i - 1)));
    nn.vW{i - 1} = zeros(size(nn.W{i - 1}));
    nn.dW{i - 1} = zeros(size(nn.W{i - 1}));
    nn.c{i - 1} = rand(nn.size(i - 1),1);
end

%% initiate weights and weight momentum for output layer
nn.Ws  = (rand(nn.size(end), nn.size(end - 1)+1) - 0.5) * 2 * 4 * sqrt(6 / (nn.size(end) + nn.size(end - 1)));
nn.vWs = zeros(size(nn.Ws));
nn.dWs = zeros(size(nn.Ws));