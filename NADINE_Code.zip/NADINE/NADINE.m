% MIT License
%
% Copyright (c) 2019
%
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
%
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
%
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.
%% list of equation
% line 103 inside the netrainstacked.m - equation (1 and 2)
%  line 72 inside the netrainstacked.m - equation (3)
%  line 126 inside the netrainstacked.m - equation (4)
%  line 170 inside the netrainstacked.m - equation (5)
%  line 184 - equation (7)
%  line 187,188 - equation (8)
%  line 211 inside the netrainstacked.m - equation (9)
%   line 153 - equation (10)

function [parameter,performance] = NADINE(data,I,name)
%% divide the data into nFolds chunks
fprintf('========= NADINE algorithm is started=========\n')
tic
timeStampK = round(size(data,1)/1000);                 % number of data chunk
[nData,mn] = size(data);
M = mn - I;
l = 0;
chunk_size = round(nData/timeStampK);
round_nFolds = floor(nData/chunk_size);
Data = {};
if round_nFolds == timeStampK
    if timeStampK == 1
        Data{1} = data;
    else
        for i=1:timeStampK
            l=l+1;
            Data1 = data(((i-1)*chunk_size+1):i*chunk_size,:);
            Data{l} = Data1;
        end
    end
else
    if timeStampK == 1
        Data{1} = data;
    else
        for i=1:timeStampK-1
            l=l+1;
            Data1 = data(((i-1)*chunk_size+1):i*chunk_size,:);
            Data{l} = Data1;
        end
        foldplus = randperm(timeStampK-1,1);
        Data{timeStampK} = Data{foldplus};
    end
end
clear data Data1

%% initiate model
K = 1;
parameter.networkConfiguration = 'stacked';    % stacked / parallel
parameter.nn = netconfig([I K M]);

%% initiate anomaly calculation
parameter.anomaly.Lambda              = 0.98;            % Forgetting factor
parameter.anomaly.StabilizationPeriod = 20; % The length of stabilization period.
parameter.anomaly.na                  = 10;                  % number of consequent anomalies to be considered as change
parameter.anomaly.Threshold1          = chi2inv(0.99 ,I);
parameter.anomaly.Threshold2          = chi2inv(0.999,I);
parameter.anomaly.firstinitdepth      = I + 1;
parameter.anomaly.ky                  = 0;
parameter.anomaly.TrackerA            = 1*eye(I);
parameter.anomaly.TrackerC            = zeros(1,I);
parameter.anomaly.CACounter           = 0;
parameter.anomaly.ChangePoints        = [];        % Index of identified change points
parameter.anomaly.Anomaliesx          = [];          % Identified anoamlies input
parameter.anomaly.AnomaliesT          = [];          % Identified anoamlies target
parameter.nn.outputConnect            = 0;             % parallel connection

%% initiate node evolving iterative parameters
d                       = 1;     % number of hidden layer
parameter.ev{1}.hidlayer       = d;
parameter.ev{1}.kp          = 0;
parameter.ev{1}.miu_x_old   = 0;
parameter.ev{1}.var_x_old   = 0;
parameter.ev{1}.kl          = 0;
parameter.ev{1}.K           = K;
parameter.ev{1}.node        = [];
parameter.ev{1}.BIAS2       = [];
parameter.ev{1}.VAR         = [];
parameter.ev{1}.miu_NS_old  = 0;
parameter.ev{1}.var_NS_old  = 0;
parameter.ev{1}.miu_NHS_old = 0;
parameter.ev{1}.var_NHS_old = 0;
parameter.ev{1}.miumin_NS   = [];
parameter.ev{1}.miumin_NHS  = [];
parameter.ev{1}.stdmin_NS   = [];
parameter.ev{1}.stdmin_NHS  = [];

%% initiate drift detection parameter
alpha_w = 0.0005;
alpha_d = 0.0001;
alpha   = 0.0001;

%% initiate layer update parameter
% MeanGoodNodeRatioOld = 0;
% VarGoodNodeRatioOld = 0;

%% main loop, prequential evaluation
for k = 1:timeStampK
    %% load the data chunk-by-chunk
    network_evolhl(k,(1:parameter.nn.n-2))=parameter.nn.size(1,2:end-1);
    numhl_evol(k)=parameter.nn.n-2;
    
    B = Data{k}(:,1:I);
    Y = Data{k}(:,I+1:mn);
    clear Data{t}
    
    %% neural network testing
    fprintf('=========Chunk %d of %d=========\n', k, size(Data,2))
    disp('Discriminative Testing: running ...');
    parameter.nn = nettestsadl(parameter.nn,B,Y);
    LossFunct(k)=parameter.nn.L;
    parameter.ev{parameter.nn.index}.t = k;
    cr(k) = parameter.nn.cr;
    ClassificationRate(k) = mean(cr);
    fprintf('Accummulated average classification rate : %d\n', ClassificationRate(k))
    disp('Discriminative Testing: ... finished');
    if k == timeStampK - 1
        fprintf('========= Autonomous Deep Learning (DEVNN) has finished=========\n')
        break  % last chunk only testing
    end
    
    %% Calculate correlation between hidden layers output and softmax output
    
    if d > 1   %(layer-->(hidden layer)
        parameter.HnCorrOut = {};
        totalNode = 0;
        totalGoodCorrNode = 0;
        for i = 1:d
            for hn = 2:parameter.ev{i}.K+1 % hidden node nr 2, karena nomor 1 adalah bias
                HnCorrOut = zeros(1,M);
                for o = 1:M
                    temporary    = corrcoef(parameter.nn.a{i + 1}(:,hn),parameter.nn.as(:,o));
                    HnCorrOut(o) = abs(temporary(2,1));%correlation of all nodes in the  hidden layer i to the output
                end
                parameter.HnCorrOut{i}(hn-1) = mean(HnCorrOut);%rata-rata correlation
            end
            SCorr(i) = mean(parameter.HnCorrOut{i});
        end
        
        % Adaptive Learning Rate
        parameter.nn.learningRate = zeros(1,d);
        parameter.nn.learningRate = 0.01*exp(-1*(1./SCorr-1));
        disp(parameter.nn.learningRate);
        disp(SCorr);
    end
    
    
    %% Drift detection
    if k > 1
        cuttingpoint = 0;
        pp = size(Y,1);
        F_cut = zeros(pp,1);
        F_cut(parameter.nn.bad,:) = 1;
        [Fupper,~] = max(F_cut);
        [Flower,~] = min(F_cut);%(Fupper - Flower) - Statistic of Accuracy \tilde_{A}
        miu_F = mean(F_cut);%Fcut <-A
        for cut = 1:pp
            miu_G = mean(F_cut(1:cut,:));%B
            [Gupper,~] = max(F_cut(1:cut,:));%B_atas
            [Glower,~] = min(F_cut(1:cut,:));%B_bawah    (Gupper - Glower) - Statistic of Accuracy \tilde_{B}
            epsilon_G = (Gupper - Glower)*sqrt(((pp)/(2*cut*(pp))*log(1/alpha)));%epsilon Xcut. hoefding error bound B
            epsilon_F = (Fupper - Flower)*sqrt(((pp)/(2*cut*(pp))*log(1/alpha)));%epsilon Fcut  hoefding error bound A
            if (epsilon_G + miu_G) >= (miu_F + epsilon_F)
                cuttingpoint = cut;
                miu_H = mean(F_cut(cuttingpoint+1:end,:));
                epsilon_D = (Fupper-Flower)*sqrt(((pp - cuttingpoint)/(2*cuttingpoint*(pp - cuttingpoint)))  *log(1/alpha_d));
                epsilon_W = (Fupper-Flower)*sqrt(((pp - cuttingpoint)/(2*cuttingpoint*(pp - cuttingpoint)))*log(1/alpha_w));
                break
            end
        end
        if cuttingpoint == 0
            miu_H = miu_F;
            epsilon_D = (Fupper-Flower)*sqrt(((pp-cut)/(2*cut*(pp))*log(1/alpha_d)));
            epsilon_W = (Fupper-Flower)*sqrt(((pp-cut)/(2*cut*(pp))*log(1/alpha_w)));
        end
        if abs(miu_G - miu_H) > epsilon_D && cuttingpoint > 1 && cuttingpoint < pp
            st = 1;
            disp('Drift state: DRIFT');
            d = d + 1;
            parameter.nn.hl = d;
            parameter.nn.n = parameter.nn.n + 1;
            parameter.nn.size(parameter.nn.hl+1:parameter.nn.hl+2)=[1 parameter.nn.size(parameter.nn.hl+1)];%update choi
            %             parameter.nn.learningRate = [parameter.nn.learningRate 0.01];
            fprintf('The new Layer no %d is FORMED around chunk %d\n', d, k)
            
            %% initiate NN weight parameters
            [ii,~] = size(parameter.nn.W{d-1});
            parameter.nn.W{d} = (rand(1,ii+1) - 0.5) * 2 * 4 * sqrt(6 / (M + ii));
            parameter.nn.vW{d} = zeros(1,ii+1);
            parameter.nn.dW{d} = zeros(1,ii+1);
            
            %% initiate new classifier weight
            parameter.nn.Ws = (rand(M,2) - 0.5) * 2 * 4 * sqrt(6 / (M + 2));
            parameter.nn.vWs = zeros(M,2);
            parameter.nn.dWs = zeros(M,2);
            
            %% initiate iterative parameters
            parameter.ev{d}.d       = d;
            parameter.ev{d}.kl          = 0;
            parameter.ev{d}.K           = 1;
            parameter.ev{d}.node        = [];
            parameter.ev{d}.miu_NS_old  = 0;
            parameter.ev{d}.var_NS_old  = 0;
            parameter.ev{d}.miu_NHS_old = 0;
            parameter.ev{d}.var_NHS_old = 0;
            parameter.ev{d}.miumin_NS   = [];
            parameter.ev{d}.miumin_NHS  = [];
            parameter.ev{d}.stdmin_NS   = [];
            parameter.ev{d}.stdmin_NHS  = [];
            parameter.ev{d}.BIAS2       = [];
            parameter.ev{d}.VAR         = [];
            
            %% check buffer
            if isempty(buffer_x)
                h = B;
                z = Y;
            else
                h = [buffer_x;B];
                z = [buffer_T;Y];
            end
            
            %% Constructing the input for next training
            %% update choi
            h = [parameter.anomaly.Anomaliesx;h];
            h = [ones(size(h,1),1) h];
            parameter.nn.a{1} = h;
            Y = [parameter.anomaly.AnomaliesT;z];
            buffer_x = [];
            buffer_T = [];
            
            %% reset anomaly
            parameter.anomaly.ky = 0;
            parameter.anomaly.TrackerA = 1*eye(I);
            parameter.anomaly.TrackerC = zeros(1,I);
            parameter.anomaly.CACounter = 0;
            parameter.anomaly.ChangePoints = [];        % Index of identified change points
            %             parameter.anomaly.Anomaliesx = [];          % Identified anoamlies input
            %             parameter.anomaly.AnomaliesT = [];          % Identified anoamlies target
        elseif abs(miu_G - miu_H) >= epsilon_W && abs(miu_G - miu_H) < epsilon_D
            st = 2;
            disp('Drift state: WARNING');
            buffer_x = B;
            buffer_T = Y;
        else
            st = 3;
            disp('Drift state: STABLE');
            buffer_x = [];
            buffer_T = [];
        end
    else
        st = 3;
        disp('Drift state: STABLE');
        buffer_x = [];
        buffer_T = [];
    end
    drift(k) = st;
    HL(k) = d;
    
    %% Discrinimanive training for all layers
    disp('Discriminative Training: running ...');
    parameter = nettrainstacked(parameter,Y,B);
    disp('Discriminative Training: ... finished');
    
    %% clear current chunk data
    clear Data{t}
    parameter.nn.a = {};
    fprintf('=========Hidden layers were updated=========\n')
    parameter.nn.netpamsizeAll(k)=parameter.nn.size_net_param;
end
toc

%Parameter Size Evolution
pamsizeevol=parameter.nn.netpamsizeAll;
%Execution Time
exe_time = toc
%Mean Classification Rate
r_cr = mean(cr(2:end))
%Standard Deviation Size Evolution
r_std = std(cr(2:end))
pamsizeevol=parameter.nn.netpamsizeAll;
%Network Evolution
network_evolhl;
%Number of Hidden Layer Evolution
numhl_evol;

parameter.drift = drift;
performance.exe_time = exe_time;
performance.classification_rate = [mean(cr(2:end)) std(cr(2:end))];
performance.layer = [mean(HL) std(HL)];
performance.ParameterMeans=mean(pamsizeevol);
performance.ParameterStd=std(pamsizeevol);
performance.ClassificationRate=ClassificationRate;
performance.cr=cr;
performance.LossFunct=LossFunct;
performance.HL=HL;
performance.network_evolhl=network_evolhl;
performance=generateFigure(name,performance);

% saving results on results folder
pathfolder=sprintf('results/%sresults',name);
namefile=sprintf('results/%sresults.mat',name);
saveas(gcf,pathfolder,'fig')
save(namefile,'ClassificationRate','r_cr','cr','r_std','pamsizeevol','exe_time','network_evolhl','numhl_evol','performance','HL','LossFunct');
end