% MIT License
% 
% Copyright (c) 2018 Andri Ashfahani Mahardhika Pratama
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE. XAVIER

%% main code
function [parameter,performance] = NADINE_regression(data,I)
%% divide the data into nFolds chunks
fprintf('=========Stacked Autonomous Deep Learning is started=========\n')
nFolds = round(size(data,1)/1);                 % number of data chunk
[nData,mn] = size(data);
M = mn - I;
l = 0;
chunk_size = round(nData/nFolds);
round_nFolds = floor(nData/chunk_size);
Data = {};
if round_nFolds == nFolds
    if nFolds == 1
        Data{1} = data;
    else
        for i=1:nFolds
            l=l+1;
            Data1 = data(((i-1)*chunk_size+1):i*chunk_size,:);
            Data{l} = Data1;
        end
    end
else
    if nFolds == 1
        Data{1} = data;
    else
        for i=1:nFolds-1
            l=l+1;
            Data1 = data(((i-1)*chunk_size+1):i*chunk_size,:);
            Data{l} = Data1;
        end
        foldplus = randperm(nFolds-1,1);
        Data{nFolds} = Data{foldplus};
    end
end
clear data Data1

%% initiate model
K = 1;
parameter.networkConfiguration = 'stacked';    % stacked / parallel
parameter.nn = netconfig([I K M]);
parameter.nn.output = 'linear';

%% initiate anomaly calculation
parameter.anomaly.Lambda              = 0.98;            % Forgetting factor
parameter.anomaly.StabilizationPeriod = 20; % The length of stabilization period.
parameter.anomaly.na                  = 10;                  % number of consequent anomalies to be considered as change
parameter.anomaly.Threshold1          = chi2inv(0.99 ,I);
parameter.anomaly.Threshold2          = chi2inv(0.999,I);
parameter.anomaly.firstinitdepth      = I + 1;
parameter.anomaly.ky                  = 0;
parameter.anomaly.TrackerA            = 1*eye(I);
parameter.anomaly.TrackerC            = zeros(1,I);
parameter.anomaly.CACounter           = 0;
parameter.anomaly.ChangePoints        = [];        % Index of identified change points
parameter.anomaly.Anomaliesx          = [];          % Identified anoamlies input
parameter.anomaly.AnomaliesT          = [];          % Identified anoamlies target
parameter.nn.outputConnect            = 0;             % parallel connection

%% initiate node evolving iterative parameters
layer                       = 1;     % number of hidden layer
parameter.ev{1}.layer       = layer;
parameter.ev{1}.kp          = 0;
parameter.ev{1}.miu_x_old   = 0;
parameter.ev{1}.var_x_old   = 0;
parameter.ev{1}.kl          = 0;
parameter.ev{1}.K           = K;
parameter.ev{1}.node        = [];
parameter.ev{1}.BIAS2       = [];
parameter.ev{1}.VAR         = [];
parameter.ev{1}.miu_NS_old  = 0;
parameter.ev{1}.var_NS_old  = 0;
parameter.ev{1}.miu_NHS_old = 0;
parameter.ev{1}.var_NHS_old = 0;
parameter.ev{1}.miumin_NS   = [];
parameter.ev{1}.miumin_NHS  = [];
parameter.ev{1}.stdmin_NS   = [];
parameter.ev{1}.stdmin_NHS  = [];
parameter.ev{1}.grow        = 0;
parameter.ev{1}.prune       = 0;

%% initiate layer update parameter
% MeanGoodNodeRatioOld = 0;
% VarGoodNodeRatioOld = 0;

%% main loop, prequential evaluation
countF_cut = 1;
for t = 1:nFolds
    %% load the data chunk-by-chunk
    x = Data{t}(:,1:I);
    x_ori = x;
    T = Data{t}(:,I+1:mn);
    T_ori = T;
    [bd,~] = size(T);
    clear Data{t}
    
    %% neural network testing
    start_test = tic;
    fprintf('=========Chunk %d of %d=========\n', t, size(Data,2))
    disp('Discriminative Testing: running ...');
    parameter.nn.t = t;
    
    nn = nettestsadl(parameter.nn,x,T,parameter.ev);
    parameter.nn = nn;
    
    actualOutput(bd*t+(1-bd):bd*t,:) = T;
    predictedOutput(bd*t+(1-bd):bd*t,:) = parameter.nn.as;
    
    parameter.ev{parameter.nn.index}.t = t;
    parameter.squareError(bd*t+(1-bd):bd*t,:) = parameter.nn.squareError;
%     meanSquareError(t,:) = mean(parameter.squareError);
%     fprintf('Classification rate %d\n', meanSquareError(t))
    disp('Discriminative Testing: ... finished');
    if t == nFolds - 1
        fprintf('=========Stacked Autonomous Deep Learning is finished=========\n')
        break               % last chunk only testing
    end
    parameter.nn.test_time(t) = toc(start_test);
    
    %% calculate correlation between hidden layers output and softmax output
    start_train = tic;
    if layer > 1
        parameter.HnCorrOut = {};
        for i = 1:layer
            for hn = 2:parameter.ev{i}.K+1
                HnCorrOut = zeros(1,M);
                for o = 1:M
                    temporary    = corrcoef(parameter.nn.a{i + 1}(:,hn),...
                        parameter.nn.as(:,o));
                    mm = size(temporary,1);
                    HnCorrOut(o) = abs(temporary(1,mm));
                end
                parameter.HnCorrOut{i}(hn-1) = mean(HnCorrOut);
            end
            SCorr(i) = mean(parameter.HnCorrOut{i});
        end
        parameter.nn.learningRate = zeros(1,layer);
        parameter.nn.learningRate = 0.01*exp(-1*(1./SCorr-1));
    end
    
    %% Drift detection
    window = 50;
    if mod(t,window) == 0 && t > 50
        %% initiate drift detection parameter
        alpha_w = 0.005;
        alpha_d = 0.001;
        alpha   = 0.001;
        
        F_cut = parameter.squareError(window*countF_cut+...
            (1-window):window*countF_cut,:);
        if size(F_cut,2) > 1
            F_cut = mean(F_cut,2);
        end
        countF_cut = countF_cut + 1;
        cuttingpoint = 0;
        pp = size(F_cut,1);
        [Fupper,~] = max(F_cut);
        [Flower,~] = min(F_cut);
        miu_F = mean(F_cut);
        for cut = 2:pp-1
            miu_G = mean(F_cut(1:cut,:));
            [Gupper,~] = max(F_cut(1:cut,:));
            [Glower,~] = min(F_cut(1:cut,:));
            epsilon_G = (Gupper - Glower)*sqrt(((cut)/(2*cut*(pp))*log(1/alpha)));
            epsilon_F = (Fupper - Flower)*sqrt(((pp)/(2*cut*(pp))*log(1/alpha)));
            if (epsilon_G + miu_G) >= (miu_F + epsilon_F)
                cuttingpoint = cut;
                miu_H = mean(F_cut(cuttingpoint+1:end,:));
                epsilon_D = (Fupper-Flower)*sqrt(((pp - cuttingpoint)/(2*cuttingpoint*(pp - cuttingpoint)))*log(1/alpha_d));
                epsilon_W = (Fupper-Flower)*sqrt(((pp - cuttingpoint)/(2*cuttingpoint*(pp - cuttingpoint)))*log(1/alpha_w));
                break
            end
        end
        if cuttingpoint == 0
            miu_H = miu_F;
            epsilon_D = (Fupper-Flower)*sqrt(((pp-cut)/(2*cut*(pp))*log(1/alpha_d)));
            epsilon_W = (Fupper-Flower)*sqrt(((pp-cut)/(2*cut*(pp))*log(1/alpha_w)));
        end
        F_cut = [];
        if abs(miu_G - miu_H) > epsilon_D && st ~= 1 
            st = 1;
            disp('Drift state: DRIFT');
            layer = layer + 1;
            parameter.nn.hl = layer;
            parameter.nn.n = parameter.nn.n + 1;
            fprintf('The new Layer no %d is FORMED around chunk %d\n', layer, t)
            
            %% initiate NN weight parameters
            [ii,~] = size(parameter.nn.W{layer-1});
            parameter.nn.W{layer} = normrnd(0,sqrt(2/(ii+1)),[1,ii+1]);
            parameter.nn.vW{layer} = zeros(1,ii+1);
            parameter.nn.dW{layer} = zeros(1,ii+1);
            
            %% initiate new classifier weight
            parameter.nn.Ws = normrnd(0,1,[M,2]);
            parameter.nn.vWs = zeros(M,2);
            parameter.nn.dWs = zeros(M,2);
            
            %% initiate iterative parameters
            parameter.ev{layer}.layer       = layer;
            parameter.ev{layer}.kl          = 0;
            parameter.ev{layer}.K           = 1;
            parameter.ev{layer}.node        = [];
            parameter.ev{layer}.miu_NS_old  = 0;
            parameter.ev{layer}.var_NS_old  = 0;
            parameter.ev{layer}.miu_NHS_old = 0;
            parameter.ev{layer}.var_NHS_old = 0;
            parameter.ev{layer}.miumin_NS   = [];
            parameter.ev{layer}.miumin_NHS  = [];
            parameter.ev{layer}.stdmin_NS   = [];
            parameter.ev{layer}.stdmin_NHS  = [];
            parameter.ev{layer}.BIAS2       = [];
            parameter.ev{layer}.VAR         = [];
            parameter.ev{layer}.grow        = 0;
            parameter.ev{layer}.prune       = 0;
            
            %% check buffer
            if isempty(buffer_x)
                h = x;
                z = T;
            else
                h = [buffer_x;x];
                z = [buffer_T;T];
            end
            
            %% Constructing the input for next training
            h = [parameter.anomaly.Anomaliesx;h];
            h = [ones(size(h,1),1) h];
            parameter.nn.a{1} = h;
            T = [parameter.anomaly.AnomaliesT;z];
            buffer_x = [];
            buffer_T = [];
            
            %% reset anomaly
            parameter.anomaly.ky = 0;
            parameter.anomaly.TrackerA = 1*eye(I);
            parameter.anomaly.TrackerC = zeros(1,I);
            parameter.anomaly.CACounter = 0;
            parameter.anomaly.ChangePoints = [];        % Index of identified change points
        elseif abs(miu_G - miu_H) >= epsilon_W && abs(miu_G - miu_H) < epsilon_D && st ~= 2
            st = 2;
            disp('Drift state: WARNING');
            buffer_x = x;
            buffer_T = T;
        else
            st = 3;
            disp('Drift state: STABLE');
            
            %% check buffer
            if isempty(buffer_x)
                
            else
                h = [buffer_x;x];
                h = [ones(size(h,1),1) h];
                parameter.nn.a{1} = h;
                T = [buffer_T;T];
            end
            buffer_x = [];
            buffer_T = [];
        end
    else
        st = 3;
        disp('Drift state: STABLE');
        buffer_x = [];
        buffer_T = [];
    end
    drift(t) = st;
    HL(t) = layer;
    
    %% Discrinimanive training for all layers
    if st ~= 2
        disp('Discriminative Training: running ...');
        parameter = nettrainstacked2(parameter,T,x_ori,T_ori);
        disp('Discriminative Training: ... finished');
    end
    parameter.nn.update_time(t) = toc(start_train);
    
    %% clear current chunk data
    clear Data{t}
    parameter.nn.a = {};
    fprintf('=========Hidden layers were updated=========\n')
end
clc

%% save the numerical result
parameter.drift = drift;
parameter.nFolds = nFolds;
performance.update_time = [mean(parameter.nn.update_time) std(parameter.nn.update_time)];
performance.test_time = [mean(parameter.nn.test_time) std(parameter.nn.test_time)];
performance.RMSE = (mean(parameter.squareError)).^0.5;
performance.NDEI = performance.RMSE./std(actualOutput);
performance.layer = [mean(HL) std(HL)];
meanode = [];
stdnode = [];
for i = 1:parameter.nn.hl
    a = nnz(~parameter.nn.nodes{i});
    parameter.nn.nodes{i} = parameter.nn.nodes{i}(a+1:t);
    meanode = [meanode mean(parameter.nn.nodes{i})];
    stdnode = [stdnode std(parameter.nn.nodes{i})];
end
performance.meanode = meanode;
performance.stdnode = stdnode;
performance.NumberOfParameters = parameter.nn.mnop;
parameter.HL = HL;


plot(predictedOutput)
ylim([0 1.1]);
xlim([1 nFolds]);
ylabel('i-th data point')
hold on
plot(actualOutput)
legend('predictedOutput','actualOutput')
end

% This code aims to construct neural network with several hidden layer
% one can choose to either connect every hidden layer output to
% the last output or not

function nn = netconfig(layer)
nn.size                 = layer;
nn.n                    = numel(nn.size);  %  Number of layer
nn.hl                   = nn.n - 2;        %  number of hidden layer
nn.activation_function  = 'sigm';          %  Activation functions of hidden layers: 'sigm' (sigmoid) or 'tanh_opt' (optimal tanh).
nn.learningRate         = 0.01;             %  learning rate Note: typically needs to be lower when using 'sigm' activation function and non-normalized inputs.
nn.momentum             = 0.95;             %  Momentum
nn.output               = 'softmax';       %  output unit 'sigm' (=logistic), 'softmax' and 'linear'

%% initiate weights and weight momentum for hidden layer
for i = 2 : nn.n - 1
    nn.W {i - 1} = normrnd(0,sqrt(2/(nn.size(i-1)+1)),[nn.size(i),nn.size(i - 1)+1]);
%     nn.W {i - 1} = (rand(nn.size(i),nn.size(i - 1)+1) - 0.5) * 2 * 4 * sqrt(6 / (nn.size(i) + nn.size(i - 1)));
    nn.vW{i - 1} = zeros(size(nn.W{i - 1}));
    nn.dW{i - 1} = zeros(size(nn.W{i - 1}));
    nn.c{i - 1} = rand(nn.size(i - 1),1);
end

%% initiate weights and weight momentum for output layer
nn.Ws  = normrnd(0,sqrt(2/(size(nn.W {i - 1},1)+1)),[nn.size(end),nn.size(end - 1)+1]);
nn.vWs = zeros(size(nn.Ws));
nn.dWs = zeros(size(nn.Ws));
end

function nn = netconfigtrain(layer)
nn.size   = layer;
nn.n      = numel(nn.size);
nn.activation_function              = 'sigm';       %  Activation functions of hidden layers: 'sigm' (sigmoid) or 'tanh_opt' (optimal tanh).
nn.learningRate                     = 0.01;  %2      %  learning rate Note: typically needs to be lower when using 'sigm' activation function and non-normalized inputs.
nn.momentum                         = 0.95;          %  Momentum
nn.output                           = 'softmax';    %  output unit 'sigm' (=logistic), 'softmax' and 'linear'
end

function nn = nettestsadl(nn, x, T, ev)
%% feedforward
nn = netfeedforward(nn, x, T);

%% calculate classification rate
nn.index = nn.hl;
nn.squareError = (T - nn.as).^2;

for i = 1 : nn.hl
    %% calculate the number of parameter
    if i == i
        [c,d] = size(nn.Ws);
    else
        c = 0;
        d = 0;
    end
    [a,b] = size(nn.W{i});
    nop(i) = a*b + c*d;
    
    %% calculate the number of node in each hidden layer
    nn.nodes{i}(nn.t) = ev{i}.K;
end
nn.nop(nn.t) = sum(nop);
nn.mnop = [mean(nn.nop) std(nn.nop)];
end

function nn = netfeedforward(nn, x, y)
n = nn.n;
m = size(x,1);
x = [ones(m,1) x];      % by adding 1 to the first coulomn, it means the first coulomn of W is bias
nn.a{1} = x;            % the first activity is the input itself

%% feedforward from input layer through all the hidden layer
for i = 2 : n-1
    switch nn.activation_function
        case 'sigm'
            nn.a{i} = sigmf(nn.a{i - 1} * nn.W{i - 1}',[1,0]);
        case 'relu'
            nn.a{i} = max(nn.a{i - 1} * nn.W{i - 1}',0);
    end
    nn.a{i} = [ones(m,1) nn.a{i}];
end

%% propagate to the output layer
switch nn.output
    case 'sigm'
        nn.as = sigmf(nn.a{n - 1} * nn.Ws',[1,0]);
    case 'linear'
        nn.as = nn.a{n - 1} * nn.Ws';
    case 'softmax'
        nn.as = nn.a{n - 1} * nn.Ws';
        nn.as = exp(nn.as - max(nn.as,[],2));
        nn.as = nn.as./sum(nn.as, 2);
end

%% calculate error
nn.e = y - nn.as;

%% calculate loss function
switch nn.output
    case {'sigm', 'linear'}
        nn.L = 1/2 * sum(sum(nn.e .^ 2)) / m;
    case 'softmax'
        nn.L = -sum(sum(y .* log(nn.as))) / m;
end
end

function nn = netbackpropagation(nn)
n = nn.n;
switch nn.output
    case 'sigm'
        d{n} = - nn.e .* (nn.a{n} .* (1 - nn.a{n}));
    case {'softmax','linear'}
        d{n} = - nn.e;          % dL/dy
end

for i = (n - 1) : -1 : 2
    switch nn.activation_function
        case 'sigm'
            d_act = nn.a{i} .* (1 - nn.a{i}); % contains b
        case 'tanh_opt'
            d_act = 1.7159 * 2/3 * (1 - 1/(1.7159)^2 * nn.a{i}.^2);
        case 'relu'
            d_act = zeros(1,length(nn.a{i}));
            d_act(nn.a{i}>0) = 1;
    end
    
    if i+1 == n
        d{i} = (d{i + 1} * nn.W{i}) .* d_act;
    else
        d{i} = (d{i + 1}(:,2:end) * nn.W{i}) .* d_act;
    end
end

for i = 1 : (n - 1)
    if i + 1 == n
        nn.dW{i} = (d{i + 1}' * nn.a{i});
    else
        nn.dW{i} = (d{i + 1}(:,2:end)' * nn.a{i});
    end
end
end

function nn = netffsingle(nn, x, y)

n = nn.n;
m = size(x,1);
nn.a{1} = x;

%% feedforward from input layer through all the hidden layer
for i = 2 : n-1
    switch nn.activation_function
        case 'sigm'
            nn.a{i} = sigmf(nn.a{i - 1} * nn.W{i - 1}',[1,0]);
        case 'relu'
            nn.a{i} = max(nn.a{i - 1} * nn.W{i - 1}',0);
    end
    nn.a{i} = [ones(m,1) nn.a{i}];
end

%% propagate to the output layer
switch nn.output
    case 'sigm'
        nn.a{n} = sigmf(nn.a{n - 1} * nn.W{n - 1}',[1,0]);
    case 'linear'
        nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
    case 'softmax'
        nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
        nn.a{n} = exp( nn.a{n} - max(nn.a{n},[],2));
        nn.a{n} = nn.a{n}./sum(nn.a{n}, 2);
end

%% calculate error
nn.e = y - nn.a{n};

% %% calculate loss function
% switch nn.output
%     case {'sigm', 'linear'}
%         nn.L = 1/2 * sum(sum(nn.e .^ 2)) / m;
%     case 'softmax'
%         nn.L = -sum(sum(y .* log(nn.a{n}))) / m;
% end
end

function nn = netupdatestacked(nn)
lr = [nn.learningRate 0.01];
if numel(lr) ~= nn.n - 1
    lr = [lr 0.01];
end
for i = 1 : (nn.n - 1)
    if lr(i) > 0
        dW = nn.dW{i};
        dW = lr(i) * dW;
        if(nn.momentum > 0)
            nn.vW{i} = nn.momentum*nn.vW{i} + dW;
            dW = nn.vW{i};
        end
        %% apply gradient
        nn.W{i} = nn.W{i} - dW;
    end
end
end

% MIT License
% 
% Copyright (c) 2018 Andri Ashfahani Mahardhika Pratama
% 
% Permission is hereby granted, free of charge, to any person obtaining a copy
% of this software and associated documentation files (the "Software"), to deal
% in the Software without restriction, including without limitation the rights
% to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
% copies of the Software, and to permit persons to whom the Software is
% furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included in all
% copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
% IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
% FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
% AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
% LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
% OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
% SOFTWARE.

function parameter  = nettrainstacked2(parameter,y,x_ori,T_ori)
%% initiate performance matrix
ka = 0;
ky = parameter.anomaly.ky;
ca = size(parameter.nn.a{1},2);

%% initiate performance matrix
ly          = parameter.nn.hl;
kp          = parameter.ev{1}.kp;
miu_x_old   = parameter.ev{1}.miu_x_old;
var_x_old   = parameter.ev{1}.var_x_old;
kl          = parameter.ev{ly}.kl;
K           = parameter.ev{ly}.K;
node        = parameter.ev{ly}.node;
BIAS2       = parameter.ev{ly}.BIAS2;
VAR         = parameter.ev{ly}.VAR;
miu_NS_old  = parameter.ev{ly}.miu_NS_old;
var_NS_old  = parameter.ev{ly}.var_NS_old;
miu_NHS_old = parameter.ev{ly}.miu_NHS_old;
var_NHS_old = parameter.ev{ly}.var_NHS_old;
miumin_NS   = parameter.ev{ly}.miumin_NS;
miumin_NHS  = parameter.ev{ly}.miumin_NHS;
stdmin_NS   = parameter.ev{ly}.stdmin_NS;
stdmin_NHS  = parameter.ev{ly}.stdmin_NHS;
grow        = parameter.ev{ly}.grow;
prune       = parameter.ev{ly}.prune;

%% initiate training model
net = netconfigtrain([1 1 1]);
net.activation_function = parameter.nn.activation_function;
net.output = parameter.nn.output;
net.n = parameter.nn.n;
net.learningRate = parameter.nn.learningRate;

%% substitute the weight to be trained to training model
for lyr = 1:parameter.nn.n - 1
    if lyr + 1 == parameter.nn.n
        net.W{lyr}  = parameter.nn.Ws;
        net.vW{lyr} = parameter.nn.vWs;
        net.dW{lyr} = parameter.nn.dWs;
    else
        net.W{lyr}  = parameter.nn.W{lyr};
        net.vW{lyr} = parameter.nn.vW{lyr};
        net.dW{lyr} = parameter.nn.dW{lyr};
    end
end
[~,bb] = size(parameter.nn.W{ly});

%% load the data for training
x     = parameter.nn.a{1};
[N,I] = size(x);
kk    = randperm(N);
x     = x(kk,:);
y     = y(kk,:);

%% xavier initialization
if ly > 1
    n_in = parameter.ev{ly-1}.K;
else
    n_in = parameter.nn.size(1);
end

%% main loop, train the model
for k = 1 : N
    kp = kp + 1;
    kl = kl + 1;
    
%     %% feedforward #1
%     net = netffsingle(net, x(k,:), y(k,:));
    ky = ky + 1;    
    
    %% Incremental calculation of x_tail mean and variance
    [miu_x,std_x,var_x] = meanstditer(miu_x_old,var_x_old,parameter.nn.a{1}(k,:),kp);
    miu_x_old = miu_x;
    var_x_old = var_x;
    
    %% Expectation of z
    py = probit(miu_x,std_x)';
    for ii = 1:parameter.nn.hl
        py = sigmf(net.W{ii}*py,[1,0]);
        py = [1;py];
        if ii == 1
            Ey2 = py.^2;
        end
    end
    Ey = py;
    Ez = net.W{lyr}*Ey;
    if parameter.nn.hl > 1
        py = Ey2;
        for ii = 2:parameter.nn.hl
            py = sigmf(net.W{ii}*py,[1,0]);
            py = [1;py];
        end
        Ey2 = py;
    end
    Ez2 = net.W{lyr}*Ey2;
    
    %% Network mean calculation
    bias2 = (Ez - y(k,:)').^2;
    ns = bias2;
    NS = norm(ns,'fro');
    
    %% Incremental calculation of NS mean and variance
    [miu_NS,std_NS,var_NS] = meanstditer(miu_NS_old,var_NS_old,NS,kl);
    miu_NS_old = miu_NS;
    var_NS_old = var_NS;
    miustd_NS = miu_NS + std_NS;
    miuNS(k,:) = miu_NS;
    if kl <= 2 || grow == 1
        miumin_NS = miu_NS;
        stdmin_NS = std_NS;
    else
        if miu_NS < miumin_NS
            miumin_NS = miu_NS;
        end
        if std_NS < stdmin_NS
            stdmin_NS = std_NS;
        end
    end
    miustdmin_NS = miumin_NS + (1.25*exp(-NS)+0.75)*stdmin_NS;
    BIAS2(kl,:)  = miu_NS;
    
    %% growing hidden unit
    if miustd_NS >= miustdmin_NS && kl > 2
        grow = 1;
        K = K + 1;
        fprintf('The new node no %d is FORMED around sample %d\n', K, k)
        node(k+1) = K;
        net.W{ly} = [net.W{ly};normrnd(0,sqrt(2/(n_in+1)),[1,bb])];
        net.vW{ly} = [net.vW{ly};zeros(1,bb)];
        net.dW{ly} = [net.dW{ly};zeros(1,bb)];
        net.W{ly+1} = [net.W{ly+1} normrnd(0,sqrt(2/(K+1)),[parameter.nn.size(end),1])];
        net.vW{ly+1} = [net.vW{ly+1} zeros(parameter.nn.size(end),1)];
        net.dW{ly+1} = [net.dW{ly+1} zeros(parameter.nn.size(end),1)];
    else
        grow = 0;
        node(k+1) = K;
    end
    
    %% Network variance calculation
    var = Ez2 - Ez.^2;
    NHS = norm(var,'fro');
    
    %% Incremental calculation of NHS mean and variance
    [miu_NHS,std_NHS,var_NHS] = meanstditer(miu_NHS_old,var_NHS_old,NHS,kl);
    miu_NHS_old = miu_NHS;
    var_NHS_old = var_NHS;
    miustd_NHS = miu_NHS + std_NHS;
    miuNHS(k,:) = miu_NHS;
    if kl <= I+1 || prune == 1
        miumin_NHS = miu_NHS;
        stdmin_NHS = std_NHS;
    else
        if miu_NHS < miumin_NHS
            miumin_NHS = miu_NHS;
        end
        if std_NHS < stdmin_NHS
            stdmin_NHS = std_NHS;
        end
    end
    miustdmin_NHS = miumin_NHS + 2*(1.25*exp(-NHS)+0.75)*stdmin_NHS;
    VAR(kl,:)     = miu_NHS;
    
    %% pruning hidden unit
    if grow == 0 && K > 1 && miustd_NHS >= miustdmin_NHS && kl > I+1
        HS = Ey(2:end);
        [~,BB] = min(HS);
        fprintf('The node no %d is PRUNED around sample %d\n', BB, k)
        prune = 1;
        K = K - 1;
        node(k+1) = K;
        net.W{ly}(BB,:) = [];
        net.vW{ly}(BB,:) = [];
        net.dW{ly}(BB,:) = [];
        net.W{ly+1}(:,BB+1) = [];
        net.vW{ly+1}(:,BB+1) = [];
        net.dW{ly+1}(:,BB+1) = [];
    else
        node(k+1) = K;
        prune = 0;
    end
    
    %% feedforward
    net = netffsingle(net, x(k,:), y(k,:));
    
    %% feedforward #2, executed if there is a hidden node changing
    net = netbackpropagation(net);
    net = netupdatestacked(net);
    
    %% anomaly calculation
    if k <= size(x_ori,1)
        if ky <= ca
            parameter.anomaly.TrackerC = meaniter(parameter.anomaly.TrackerC,x_ori(k,:),ky);
        elseif ky > ca
            mahaldist = (x_ori(k,:) - parameter.anomaly.TrackerC)*parameter.anomaly.TrackerA*(x_ori(k,:) - parameter.anomaly.TrackerC)';
%             confCandidate = sort(net.a{net.n},'descend');
%             y1 = confCandidate(1);
%             y2 = confCandidate(2);
%             confFinal = y1/(y1+y2);
            if (ky > parameter.anomaly.StabilizationPeriod)
                if (mahaldist > parameter.anomaly.Threshold1 && mahaldist < parameter.anomaly.Threshold2) % confFinal <= 0.55 ||  check for anomalies (mahaldist > parameter.anomaly.Threshold1 && mahaldist < parameter.anomaly.Threshold2) ||
                    ka = ka + 1;
                    indexAnomaly(ka) = k;
                    parameter.anomaly.CACounter = 0;
                else
                    parameter.anomaly.CACounter = parameter.anomaly.CACounter + 1;
                end
            end
            if(parameter.anomaly.CACounter >= parameter.anomaly.na)
                parameter.anomaly.ChangePoints = [parameter.anomaly.ChangePoints;ky - parameter.anomaly.CACounter];
                parameter.anomaly.CACounter = 0;
            end
            [parameter.anomaly.TrackerA,parameter.anomaly.TrackerC] = FFIDCAD(parameter.anomaly.TrackerA,parameter.anomaly.TrackerC,ky,parameter.anomaly.Lambda,x_ori(k,:));
        end
    end
end

%% create buffer for anomaly
if ka ~= 0
    if size(parameter.anomaly.Anomaliesx,1) < 10000
        parameter.anomaly.Anomaliesx = [parameter.anomaly.Anomaliesx;parameter.nn.a{1}(indexAnomaly,2:end)];
        parameter.anomaly.AnomaliesT = [parameter.anomaly.AnomaliesT;T_ori(indexAnomaly,:)];
    elseif size(parameter.anomaly.Anomaliesx,1) >= 10000
        n_anomaly = size(parameter.nn.a{1}(indexAnomaly,2:end),1);
        parameter.anomaly.Anomaliesx = [parameter.anomaly.Anomaliesx(n_anomaly+1:end,:);parameter.nn.a{1}(indexAnomaly,2:end)];
        parameter.anomaly.AnomaliesT = [parameter.anomaly.AnomaliesT(n_anomaly+1:end,:);T_ori(indexAnomaly,:)];
    end
end

%% reset momentum and gradient
for lyr = 1:parameter.nn.n - 1
    if lyr + 1 == parameter.nn.n
        parameter.nn.Ws = net.W{lyr};
        parameter.nn.vWs = net.vW{lyr}*0;
        parameter.nn.dWs = net.dW{lyr}*0;
    else
        parameter.nn.W{lyr} = net.W{lyr};
        parameter.nn.vW{lyr} = net.vW{lyr}*0;
        parameter.nn.dW{lyr} = net.dW{lyr}*0;
    end
end

%% substitute the recursive calculation
parameter.ev{1}.kp           = kp;
parameter.ev{1}.miu_x_old    = miu_x_old;
parameter.ev{1}.var_x_old    = var_x_old;
parameter.ev{ly}.kl          = kl;
parameter.ev{ly}.K           = K;
parameter.ev{ly}.node        = node;
parameter.ev{ly}.BIAS2       = BIAS2;
parameter.ev{ly}.VAR         = VAR;
parameter.ev{ly}.miu_NS_old  = miu_NS_old;
parameter.ev{ly}.var_NS_old  = var_NS_old;
parameter.ev{ly}.miu_NHS_old = miu_NHS_old;
parameter.ev{ly}.var_NHS_old = var_NHS_old;
parameter.ev{ly}.miumin_NS   = miumin_NS;
parameter.ev{ly}.miumin_NHS  = miumin_NHS;
parameter.ev{ly}.stdmin_NS   = stdmin_NS;
parameter.ev{ly}.stdmin_NHS  = stdmin_NHS;
parameter.ev{ly}.grow        = grow;
parameter.ev{ly}.prune       = prune;
end

function p = probit(miu,std)
p = (miu./(1 + pi.*(std.^2)./8).^0.5);
end

function [miu] = meaniter(miu_old,x,k)
miu = miu_old + (x - miu_old)./k;
end

function [miu,std,var] = meanstditer(miu_old,var_old,x,k)
miu = miu_old + (x - miu_old)./k;
var = var_old + (x - miu_old).*(x - miu);
std = sqrt(var/k);
end

%======================================================
% Author: Masud Moshtaghi
% Created: 2011-03-21
% Calculates one step of recursive formulat update
% 
%=======================================================
function [A,C] = FFIDCAD(PrevA,PrevC,MultiplierN, Lambda, X)
EffectiveN = 200;                                    %3*(1/(1-Lambda));
MultiplierN = min([MultiplierN EffectiveN]);
temp1 = (X - PrevC)*PrevA*(X - PrevC)';
temp1 = temp1 + (MultiplierN - 1)/Lambda;
Mplier = ((MultiplierN)/((MultiplierN - 1)*Lambda));
A = PrevA - ((PrevA*(X - PrevC)'*(X - PrevC)*PrevA)/temp1);
A = Mplier*A;
C = Lambda*PrevC + (1 - Lambda)*X;
end

%% calculate performance metrics
function [f_measure,g_mean,recall,precision,err] = stats(f, h, mclass)
%   [f_measure,g_mean,recall,precision,err] = stats(f, h, mclass)
%     @f - vector of true labels
%     @h - vector of predictions on f
%     @mclass - number of classes
%     @f_measure
%     @g_mean
%     @recall
%     @precision
%     @err
%

%     stats.m
%     Copyright (C) 2013 Gregory Ditzler
%
%     This program is free software: you can redistribute it and/or modify
%     it under the terms of the GNU General Public License as published by
%     the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This program is distributed in the hope that it will be useful,
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU General Public License for more details.
%
%     You should have received a copy of the GNU General Public License
%     along with this program.  If not, see <http://www.gnu.org/licenses/>.

F = index2vector(f, mclass);
H = index2vector(h, mclass);

recall = compute_recall(F, H, mclass);
err = 1 - sum(diag(H'*F))/sum(sum(H'*F));
precision = compute_precision(F, H, mclass);
g_mean = compute_g_mean(recall, mclass);
f_measure = compute_f_measure(F, H, mclass);
end

function g_mean = compute_g_mean(recall, mclass)
g_mean = (prod(recall))^(1/mclass);
end

function f_measure = compute_f_measure(F, H, mclass)
f_measure = zeros(1, mclass);
for c = 1:mclass
    f_measure(c) = 2*F(:, c)'*H(:, c)/(sum(H(:, c)) + sum(F(:, c)));
end
f_measure(isnan(f_measure)) = 1;
end

function precision = compute_precision(F, H, mclass)
precision = zeros(1, mclass);
for c = 1:mclass
    precision(c) = F(:, c)'*H(:, c)/sum(H(:, c));
end
precision(isnan(precision)) = 1;
end

function recall = compute_recall(F, H, mclass)
recall = zeros(1, mclass);
for c = 1:mclass
    recall(c) = F(:, c)'*H(:, c)/sum(F(:, c));
end
recall(isnan(recall)) = 1;
end

function y = index2vector(x, mclass)
y = zeros(numel(x), mclass);
for n = 1:numel(x)
    y(n, x(n)) = 1;
end
end