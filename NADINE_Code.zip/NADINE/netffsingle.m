function nn = netffsingle(nn, x, y)

n = nn.n;
m = size(x,1);
nn.a{1} = x;

%% feedforward from input layer through all the hidden layer
for i = 2 : n-1
    switch nn.activation_function
        case 'sigm'
            nn.a{i} = sigmf(nn.a{i - 1} * nn.W{i - 1}',[1,0]);
        case 'relu'
            nn.a{i} = max(nn.a{i - 1} * nn.W{i - 1}',0);
    end
    nn.a{i} = [ones(m,1) nn.a{i}];
end

%% propagate to the output layer
switch nn.output
    case 'sigm'
        nn.a{n} = sigmf(nn.a{n - 1} * nn.W{n - 1}',[1,0]);
    case 'linear'
        nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
    case 'softmax'
        nn.a{n} = nn.a{n - 1} * nn.W{n - 1}';
        nn.a{n} = exp( nn.a{n} - max(nn.a{n},[],2));
        nn.a{n} = nn.a{n}./sum(nn.a{n}, 2);
end
%% calculate error
nn.e = y - nn.a{n};

%% calculate loss function
switch nn.output
    case {'sigm', 'linear'}
        nn.L = 1/2 * sum(sum(nn.e .^ 2)) / m;
    case 'softmax'
        nn.L = -sum(sum(y .* log(nn.a{n}))) / m;
end
end