function perform = generateFigure(name,performance)        

ClassificationRate=performance.ClassificationRate;nFolds=length(ClassificationRate)+1;
cr=performance.cr;
LossFunct=performance.LossFunct;
HL=performance.HL;
network_evolhl=performance.network_evolhl;

subplot(4,2,1)
plot(ClassificationRate)
ylim([0.4 1]);
xlim([1 nFolds]);
ylabel({'Classification';'Rate'})
xlabel('Iteration/Chunk')
title({'a. The accummulated average of testing classification' sprintf('rate of %s dataset  over time', name) })

subplot(4,2,2)
plot(cr,'Color',[0 1 0])
ylim([0.4 1]);
xlim([1 nFolds]);
ylabel({'Classification';'Rate (t)'})
xlabel('Iteration/Chunk')
title({'b. The testing classification rate' sprintf('of %s dataset for each chunk', name)})
 
subplot(4,2,3)
plot(LossFunct,'Color',[1 0 0])
ylabel({'Discriminative' ;'Loss Function (t)'})
xlim([1 nFolds]);
xlabel('Iteration/Chunk');
title({sprintf('c. Discriminative Loss Function of %s for each chunk', name)})

subplot(4,2,4)
height=250;
plot(HL,'Color',[0 0 1])
ylabel({'Number of'; 'Hidden Layer'})
xlim([1 nFolds]);
xlabel('Iteration/Chunk');
title({'d. The evolution of the number' ' of hidden layer in the network over time'})

subplot(4,1,[3 4])
width=550;
height=400;
plot(network_evolhl,'LineWidth',2,...
    'Color',[0.49 0.18 0.56])
ylabel('Number of hidden nodes')
xlim([1 nFolds]);
xlabel('Iteration/Chunk');
title({'e. The evolution of the number of hidden nodes in each layer in the network overtime'})

pathfolder=sprintf('results/%sresults',name);
namefile=sprintf('results/%sresults.mat',name);
perform=performance;
end

