%======================================================
% Author: Masud Moshtaghi
% Created: 2011-03-21
% Calculates one step of recursive formulat update
% 
%=======================================================
function [A,C] = FormulatUpdate(PrevA,PrevC,MultiplierN, Lambda, X)
EffectiveN = 200;                                    %3*(1/(1-Lambda));
MultiplierN = min([MultiplierN EffectiveN]);
temp1 = (X - PrevC)*PrevA*(X - PrevC)';
temp1 = temp1 + (MultiplierN - 1)/Lambda;
Mplier = ((MultiplierN)/((MultiplierN - 1)*Lambda));
A = PrevA - ((PrevA*(X - PrevC)'*(X - PrevC)*PrevA)/temp1);
A = Mplier*A;
C = Lambda*PrevC + (1 - Lambda)*X;
end