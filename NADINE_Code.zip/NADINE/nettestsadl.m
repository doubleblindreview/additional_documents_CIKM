function nn = nettestsadl(nn, x, T)
%% feedforward
nn = netfeedforward(nn, x, T);
[n,~] = size(T);

%% obtain trueclass label
[~,act] = max(T,[],2);

%% obtain the class label
[~,nn.classlabel] = max(nn.as,[],2);

%% calculate classification rate
nn.bad = find(nn.classlabel ~= act);
nn.cr = 1 - numel(nn.bad)/n;
nn.index = nn.hl;
end