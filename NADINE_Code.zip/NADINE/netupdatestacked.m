function nn = netupdatestacked(nn)
lr = [nn.learningRate 0.01];
if numel(lr) ~= nn.n - 1
    lr = [lr 0.01];
end
for i = 1 : (nn.n - 1)
    if lr(i) > 0
        dW = nn.dW{i};
        dW = lr(i) * dW;
        if(nn.momentum > 0)
            nn.vW{i} = nn.momentum*nn.vW{i} + dW;
            dW = nn.vW{i};
        end
        nn.W{i} = nn.W{i} - dW;
    end
end
end