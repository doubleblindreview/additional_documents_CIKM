function [miu] = meaniter(miu_old,x,k)
miu = miu_old + (x - miu_old)./k;
end