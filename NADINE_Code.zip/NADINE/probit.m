function p = probit(miu,std)
p = (miu./(1 + pi.*(std.^2)./8).^0.5);
end