function nn = netfeedforward(nn, x, y)
n = nn.n;
m = size(x,1);
x = [ones(m,1) x];      % by adding 1 to the first coulomn, it means the first coulomn of W is bias
nn.a{1} = x;            % the first activity is the input itself

%% feedforward from input layer through all the hidden layer
for i = 2 : n-1
    switch nn.activation_function
        case 'sigm'
            nn.a{i} = sigmf(nn.a{i - 1} * nn.W{i - 1}',[1,0]);
        case 'relu'
            nn.a{i} = max(nn.a{i - 1} * nn.W{i - 1}',0);
    end
    nn.a{i} = [ones(m,1) nn.a{i}];
end

%% propagate to the output layer
switch nn.output
    case 'sigm'
        nn.as = sigmf(nn.a{n - 1} * nn.Ws',[1,0]);
    case 'linear'
        nn.as = nn.a{n - 1} * nn.Ws';
    case 'softmax'
        nn.as = nn.a{n - 1} * nn.Ws';
%         nn.as = exp(nn.as - max(nn.as,[],2));%aa
%       
%        
%         nn.as = nn.as./sum(nn.as, 2);
        nn.as = exp(nn.as - repmat(max(nn.as,[],2),1,size(nn.as,2)));
        nn.as = nn.as./     repmat( sum(nn.as, 2),1,  size(nn.as,2)) ;
end

%% calculate error
nn.e = y - nn.as;

%% calculate loss function
switch nn.output
    case {'sigm', 'linear'}
        nn.L = 1/2 * sum(sum(nn.e .^ 2)) / m;
    case 'softmax'
        nn.L = -sum(sum(y .* log(nn.as))) / m;
end
end