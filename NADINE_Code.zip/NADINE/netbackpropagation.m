function nn = netbackpropagation(nn)
n = nn.n;
switch nn.output
    case 'sigm'
        d{n} = - nn.e .* (nn.a{n} .* (1 - nn.a{n}));
    case {'softmax','linear'}
        d{n} = - nn.e;          % dL/dy
end

for i = (n - 1) : -1 : 2
    switch nn.activation_function
        case 'sigm'
            d_act = nn.a{i} .* (1 - nn.a{i}); % contains b
        case 'tanh_opt'
            d_act = 1.7159 * 2/3 * (1 - 1/(1.7159)^2 * nn.a{i}.^2);
        case 'relu'
            d_act = zeros(1,length(nn.a{i}));
            d_act(nn.a{i}>0) = 1;
    end
    
    if i+1 == n
        d{i} = (d{i + 1} * nn.W{i}) .* d_act;
    else
        d{i} = (d{i + 1}(:,2:end) * nn.W{i}) .* d_act;
    end
end

for i = 1 : (n - 1)
    if i + 1 == n
        nn.dW{i} = (d{i + 1}' * nn.a{i});
    else
        nn.dW{i} = (d{i + 1}(:,2:end)' * nn.a{i});
    end
end
end