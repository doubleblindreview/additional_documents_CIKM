function parameter  = nettrainstacked(parameter,y,B)
grow = 0;
prune = 0;

%% initiate performance matrix
ka = 0;
ky = parameter.anomaly.ky;
ca = size(parameter.nn.a{1},2);

%% initiate performance matrix
ly          = parameter.nn.hl;
kp          = parameter.ev{1}.kp;
miu_x_old   = parameter.ev{1}.miu_x_old;
var_x_old   = parameter.ev{1}.var_x_old;
kl          = parameter.ev{ly}.kl;
K           = parameter.ev{ly}.K;
node        = parameter.ev{ly}.node;
BIAS2       = parameter.ev{ly}.BIAS2;
VAR         = parameter.ev{ly}.VAR;
miu_NS_old  = parameter.ev{ly}.miu_NS_old;
var_NS_old  = parameter.ev{ly}.var_NS_old;
miu_NHS_old = parameter.ev{ly}.miu_NHS_old;
var_NHS_old = parameter.ev{ly}.var_NHS_old;
miumin_NS   = parameter.ev{ly}.miumin_NS;
miumin_NHS  = parameter.ev{ly}.miumin_NHS;
stdmin_NS   = parameter.ev{ly}.stdmin_NS;
stdmin_NHS  = parameter.ev{ly}.stdmin_NHS;

%% initiate training model
% net = netconfigtrain([1 1 1]);
net = netconfigtrain([parameter.nn.size]);
net.activation_function = parameter.nn.activation_function;
net.n = parameter.nn.n;
net.learningRate = parameter.nn.learningRate;

%% substitute the weight to be trained to training model
for lyr = 1:parameter.nn.n - 1
    if lyr + 1 == parameter.nn.n
        net.W{lyr}  = parameter.nn.Ws;
        net.vW{lyr} = parameter.nn.vWs;
        net.dW{lyr} = parameter.nn.dWs;
    else
        net.W{lyr}  = parameter.nn.W{lyr};
        net.vW{lyr} = parameter.nn.vW{lyr};
        net.dW{lyr} = parameter.nn.dW{lyr};
    end
end
[~,bb] = size(parameter.nn.W{ly});

%% load the data for training
x     = parameter.nn.a{1};
[N,I] = size(x);
kk    = randperm(N);
x     = x(kk,:);
y     = y(kk,:);

%% main loop, train the model
for k = 1 : N
    kp = kp + 1;
    kl = kl + 1;
    
    %% feedforward #1
    net = netffsingle(net, x(k,:), y(k,:));% the loss function is calculated here
    ky = ky + 1;
    
    %% Incremental calculation of x_tail mean and variance
    [miu_x,std_x,var_x] = meanstditer(miu_x_old,var_x_old,net.a{1},kp);
    miu_x_old = miu_x;
    var_x_old = var_x;
    
    %% Expectation of z
    Ey = probit(miu_x,std_x)'; % probit function is used (expectation is not linear)
    for ii = 1:parameter.nn.hl
        py = sigmf(net.W{ii}*Ey,[1,0]); 
        py = [1;py];
        if ii == 1
            Ey2 = py.^2;
        end
        Ey=py;
    end
    clear Ey; %
    Ey = py;%
    Ez = net.W{lyr}*Ey;%
    Ez = exp(Ez);%
    Ez = Ez./sum(Ez);%
    
    if parameter.nn.hl > 1
        py = Ey2;
        for ii = 2:parameter.nn.hl
            py = sigmf(net.W{ii}*py,[1,0]);
            py = [1;py];
        end
        Ey2 = py;
    end
    Ez2 = net.W{lyr}*Ey2;
    Ez2 = exp(Ez2);
    Ez2 = Ez2./sum(Ez2);% this is for variance
    
    %% Network mean calculation
    bias2 = (Ez - y(k,:)').^2; % growing
    ns = bias2;
    
    NS = norm(ns,'fro');
    
    %% Incremental calculation of NS mean and variance
    [miu_NS,std_NS,var_NS] = meanstditer(miu_NS_old,var_NS_old,NS,kp);
    miu_NS_old = miu_NS;
    var_NS_old = var_NS;
    miustd_NS = miu_NS + std_NS;
    miuNS(k,:) = miu_NS;
    if kl <= 1 || grow == 1
        miumin_NS = miu_NS;
        stdmin_NS = std_NS;
    else
        if miu_NS < miumin_NS
            miumin_NS = miu_NS;
        end
        if std_NS < stdmin_NS
            stdmin_NS = std_NS;
        end
    end
    miustdmin_NS = miumin_NS + (1.25*exp(-NS)+0.75)*stdmin_NS;
    BIAS2(kl,:)  = miu_NS;
    
    %% growing hidden unit
    if miustd_NS >= miustdmin_NS && kl > 1 % kl is the current data overtime
        grow = 1;
        K = K + 1;
        fprintf('The new node no %d is FORMED around sample %d\n', K, k)
        node(k+1) = K;net.size(parameter.nn.hl+1)=K; change=1;
        %% Random Weight initialization
        net.W{ly} = [net.W{ly}; random('normal', 0, 0.01, 1, bb)];
        net.vW{ly} = [net.vW{ly};zeros(1,bb)];
        net.dW{ly} = [net.dW{ly};zeros(1,bb)];
        %% Random Weight initialization
        wNext = size(net.W{ly+1},1);
        net.W{ly+1} = [net.W{ly+1} random('normal', 0, 0.01,wNext,1)];
        %%
        net.vW{ly+1} = [net.vW{ly+1} zeros(parameter.nn.size(end),1)];
        net.dW{ly+1} = [net.dW{ly+1} zeros(parameter.nn.size(end),1)];
    else
        grow = 0;
        node(k+1) = K;
    end
    %% Network variance calculation
    var = Ez2 - Ez.^2;
    NHS = norm(var,'fro');
    
    %% Incremental calculation of NHS mean and variance
    [miu_NHS,std_NHS,var_NHS] = meanstditer(miu_NHS_old,var_NHS_old,NHS,kp);
    miu_NHS_old = miu_NHS;
    var_NHS_old = var_NHS;
    miustd_NHS = miu_NHS + std_NHS;
    miuNHS(k,:) = miu_NHS;
    if kl <= I + 1 || prune == 1
        miumin_NHS = miu_NHS;
        stdmin_NHS = std_NHS;
    else
        if miu_NHS < miumin_NHS
            miumin_NHS = miu_NHS;
        end
        if std_NHS < stdmin_NHS
            stdmin_NHS = std_NHS;
        end
    end
    miustdmin_NHS = miumin_NHS + (2.5*exp(-NHS)+1.5)*stdmin_NHS;
    VAR(kl,:)     = miu_NHS;
    
    %% pruning hidden unit
    if grow == 0 && K > 1 && miustd_NHS >= miustdmin_NHS && kl > I + 1
        HS = Ey(2:end);
        [~,BB] = min(HS);
        fprintf('Th�e node no %d is PRUNED around sample %d\n', BB, k)
        prune = 1;
        K = K - 1;
        node(k+1) = K; net.size(parameter.nn.hl+1)=K; change=2;
        net.W{ly}(BB,:) = [];
        net.vW{ly}(BB,:) = [];
        net.dW{ly}(BB,:) = [];
        net.W{ly+1}(:,BB+1) = [];
        net.vW{ly+1}(:,BB+1) = [];
        net.dW{ly+1}(:,BB+1) = [];
    else
        node(k+1) = K;
        prune = 0;
    end
    
    if grow == 1 || prune == 1
        net = netffsingle(net, x(k,:), y(k,:));
    end
    
    %% feedforward #2, executed if there is a hidden node changing
    net = netbackpropagation(net);
    net = netupdatestacked(net);
    
    %% anomaly calculation
    if k <= size(B,1)
        if ky <= ca
            parameter.anomaly.TrackerC = meaniter(parameter.anomaly.TrackerC,B(k,:),ky);% mean over time
        elseif ky > ca
            mahaldist = (B(k,:) - parameter.anomaly.TrackerC)*parameter.anomaly.TrackerA*(B(k,:) - parameter.anomaly.TrackerC)';
            confCandidate = sort(net.a{net.n},'descend');
            y1 = confCandidate(1);
            y2 = confCandidate(2);
            confFinal = y1/(y1+y2);
            if (ky > parameter.anomaly.StabilizationPeriod)
                %Threshold 1 and Threshold 2 are obtained using chi2inv
                %(0.99,I) and chi2inv(0.999,I), the data point is regarded as an anomaly if
                % the condition below is fulfilled. After this condition is
                % executed, the CACounter is resetted to zero.
                if(mahaldist > parameter.anomaly.Threshold1 && mahaldist < parameter.anomaly.Threshold2) || confFinal <= 0.55 % check for anomalies
                    ka = ka + 1;
                    indexAnomaly(ka) = k;
                    parameter.anomaly.CACounter = 0;
                else
                    parameter.anomaly.CACounter = parameter.anomaly.CACounter + 1;
                end
            end
            if(parameter.anomaly.CACounter >= parameter.anomaly.na)
                parameter.anomaly.ChangePoints = [parameter.anomaly.ChangePoints;ky - parameter.anomaly.CACounter];
                parameter.anomaly.CACounter = 0;
            end
            [parameter.anomaly.TrackerA,parameter.anomaly.TrackerC] = FormulatUpdate(parameter.anomaly.TrackerA,parameter.anomaly.TrackerC,ky,parameter.anomaly.Lambda,B(k,:));
        end
    end
    parameter.nn.size=net.size;
end

%% create buffer for anomaly
if ka ~= 0
    if size(parameter.anomaly.Anomaliesx,1) < 5000*ly
        parameter.anomaly.Anomaliesx = [parameter.anomaly.Anomaliesx;parameter.nn.a{1}(indexAnomaly,2:end)];
        parameter.anomaly.AnomaliesT = [parameter.anomaly.AnomaliesT;y(indexAnomaly,:)];
    elseif size(parameter.anomaly.Anomaliesx,1) >= 5000*ly
        n_anomaly = size(parameter.nn.a{1}(indexAnomaly,2:end),1);
        parameter.anomaly.Anomaliesx = [parameter.anomaly.Anomaliesx(n_anomaly+1:end,:);parameter.nn.a{1}(indexAnomaly,2:end)];
        parameter.anomaly.AnomaliesT = [parameter.anomaly.AnomaliesT(n_anomaly+1:end,:);y(indexAnomaly,:)];
    end
end

size_net_param=0;
for lyr = 1:parameter.nn.n - 1
    if lyr + 1 == parameter.nn.n
        parameter.nn.Ws = net.W{lyr};
        parameter.nn.vWs = net.vW{lyr};
        parameter.nn.dWs = net.dW{lyr};
    else
        parameter.nn.W{lyr} = net.W{lyr};
        parameter.nn.vW{lyr} = net.vW{lyr};
        parameter.nn.dW{lyr} = net.dW{lyr};
    end
    if lyr>1 && lyr<parameter.nn.n
        size_net_param=size_net_param+numel(parameter.nn.W{lyr-1});
    end
end

size_net_param=size_net_param+numel(parameter.nn.Ws);
parameter.nn.size_net_param=size_net_param;

%% substitute the recursive calculation
parameter.ev{1}.kp           = kp;
parameter.ev{1}.miu_x_old    = miu_x_old;
parameter.ev{1}.var_x_old    = var_x_old;
parameter.ev{ly}.kl          = kl;
parameter.ev{ly}.K           = K;
parameter.ev{ly}.node        = node;
parameter.ev{ly}.BIAS2       = BIAS2;
parameter.ev{ly}.VAR         = VAR;
parameter.ev{ly}.miu_NS_old  = miu_NS_old;
parameter.ev{ly}.var_NS_old  = var_NS_old;
parameter.ev{ly}.miu_NHS_old = miu_NHS_old;
parameter.ev{ly}.var_NHS_old = var_NHS_old;
parameter.ev{ly}.miumin_NS   = miumin_NS;
parameter.ev{ly}.miumin_NHS  = miumin_NHS;
parameter.ev{ly}.stdmin_NS   = stdmin_NS;
parameter.ev{ly}.stdmin_NHS  = stdmin_NHS;
end