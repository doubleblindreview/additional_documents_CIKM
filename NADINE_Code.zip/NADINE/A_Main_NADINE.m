clear all
clc

%% Load the Dataset (This is for running all datasets)
for j=1:10 % modify the index if you want to specify datasets (for example: j=4:4), means that only running RFID dataset
    if (j==1)
        load 01SUSY ; I = 18; name='SUSY';
    elseif (j==2)
        load 02HEPMASS; I = 28; name='HEPMASS';
    elseif (j==3)
        load 03RLCPS ; I = 9; name='RLCPS';
    elseif (j==4)
        load 04RFID; I = 3; name='RFID';
    elseif (j==5)
        load 05Mnist; I=784;name='Mnist';
    elseif (j==6)
        load 06RMnist;I=784;name='RMnist';
    elseif (j==7)
        load 07PMnist ;  I = 784; name='PMnist';
    elseif (j==8)
        load 08KDD ; I = 41; name = 'KDD';
    elseif (j==9)
        load 09SEA; I = 3; name='SEA';
    else
        load 10HYPERPLANE; I = 4; name='HYPERPLANE';
    end
    
end

%% RUN NADINE for Five times experiment
for i=1:5 % modify the index if you want to run several times of experiment (for example: i=1:10), means that want to run 10 times experiment
    name2=strcat(num2str(i),name)
    [parameter,performance] = NADINE(data,I,name2);
end


