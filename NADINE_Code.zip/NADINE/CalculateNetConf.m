function [as2,dev1] = CalculateNetConf(network_evolhl,numhl_evol)
%as2 adalah mean network
% dev1 is std network


a=network_evolhl(:,2:end-1);
if isempty(a)%to avoid error --> because there is a change in code
    a=network_evolhl;   
end
[c,d]=size(a);

for i=1:c
    a(i,numhl_evol(i)+1:end)=0;  
end

as1=[];
as2=[];


for j=1:size(a,2)
    ccc=a(:,j)>0;
    kk=(a(:,j));
    as2(j)=mean(kk(ccc));
    dev1(j)= std(kk(ccc));
    
end
end

