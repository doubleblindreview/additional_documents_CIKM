D = 41;
%================= Parameters of the algorithm =====================
Thres = 0.999; % The threshold for anomalies, it shoud be very close to 1.
Lambda = 0.98; % Forgetting factor
StabilizationPeriod = 20; %The length of stabilization period.
na = 10; % number of consequent anomalies to be considered as change

Threshold1 = chi2inv(Thres,D);
Reduced = NewS18; % Input data
n = size(Reduced,1);
firstinitdepth = D + 1;

% Algorithm initialization
TrackerA = 1*eye(D);
TrackerC = mean(Reduced(1:firstinitdepth,1:D));
TrackerMult = D + 1;
CACounter = 0;
ChangePoints = []; % Index of identified change points

Anomalies = []; % Identified anoamlies

for i = firstinitdepth+1:1:n
    mahaldist = (Reduced(i,1:D) - TrackerC)*TrackerA*(Reduced(i,1:D) - TrackerC)';
    if (i > StabilizationPeriod)
        if(mahaldist > Threshold1) % check for anomalies
            Anomalies = [Anomalies;Reduced(i,:)];
            CACounter = 0;
        else
            CACounter = CACounter + 1;
        end
    end
    if(CACounter >= na)
        ChangePoints = [ChangePoints;i-CACounter];
        CACounter = 0;
    end
    [TrackerA,TrackerC] = FFIDCAD(TrackerA,TrackerC,i,Lambda,Reduced(i,1:D));
end